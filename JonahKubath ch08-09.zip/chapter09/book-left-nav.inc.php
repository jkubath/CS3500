<div class="rail">

   <div class="alert alert-danger">
   
   <strong><span class="glyphicon glyphicon-user"></span> John Locke</strong><br/>
   Senior Sales Rep<br/>
   <span class="member-box-links"><a>Settings</a> | <a>Logout</a></span>
   
   </div>


   <ul class="nav nav-stacked">
   <li class="nav-header">My CRM</li> 
     <li><a href="#"><span class="glyphicon glyphicon-dashboard"></span> Dashboard</a></li>
     <li><a href="#"><span class="glyphicon glyphicon-envelope"></span> Messages</a></li>
     <li><a href="#"><span class="glyphicon glyphicon-folder-open"></span> Tasks</a></li>
     <li><a href="#"><span class="glyphicon glyphicon-saved"></span> Orders</a></li>
     <li><a href="#"><span class="glyphicon glyphicon-calendar"></span> Calendar</a></li>
   <li class="nav-header">Knowledge</li> 
      <li><a href="#"><span class="glyphicon glyphicon-book"></span> Catalog</a></li>
      <li><a href="#"><span class="glyphicon glyphicon-user"></span> Customers</a></li>
   <li class="nav-header">Other</li> 
      <li><a href="#"><span class="glyphicon glyphicon-bullhorn"></span> Analytics</a></li>
      <li><a href="#"><span class="glyphicon glyphicon-cog"></span> Options</a></li>      
   </ul>

</div>
