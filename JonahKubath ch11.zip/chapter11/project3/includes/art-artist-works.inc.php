<?php 



?>

<h3>Art by  </h3>  

<div class="row">


   <div class="col-md-3">
      <div class="thumbnail">
         <img src="images/art/works/square-medium/???.jpg" title="" alt="" class="img-thumbnail img-responsive">
         <div class="caption">
            <a class="btn btn-primary btn-xs" href="display-art-work.php?id="><span class="glyphicon glyphicon-info-sign"></span> View</a>
            <button type="button" class="btn btn-success btn-xs"><span class="glyphicon glyphicon-gift"></span> Wish</button>
            <button type="button" class="btn btn-info btn-xs"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</button>
         </div>
      </div>                   
   </div>


 
            
</div>  <!-- end artist's works row -->